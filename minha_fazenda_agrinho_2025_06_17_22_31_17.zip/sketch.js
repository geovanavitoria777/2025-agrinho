// ====== VARIÁVEIS GLOBAIS DO JOGO ======
let grama; // Variável para carregar a imagem da grama (atualmente não utilizada)
let sementes = []; // Armazena todas as sementes plantadas no campo
let particulas = []; // Armazena partículas para efeitos visuais, como na colheita

// ====== CONSTANTES DE CRESCIMENTO E LIMITE ======
// Tempos de crescimento para cada estágio da planta (em milissegundos)
const TEMPO_CRESCIMENTO_ESTAGIO_1 = 3000; // 3 segundos para o broto
const TEMPO_CRESCIMENTO_ESTAGIO_2 = 6000; // 6 segundos para a planta média
const TEMPO_CRESCIMENTO_ESTAGIO_3 = 9000; // 9 segundos para a planta madura (pronta para colheita)

const MAX_SEMENTES_PLANTADAS = 50; // Número máximo de sementes que podem ser plantadas no campo

// ====== ESTADO DO JOGO ======
let estadoJogo = 'telaInicial'; // Controla qual tela o jogador está vendo: 'telaInicial', 'jogando', 'telaVenda', 'telaLoja'

// ====== OBJETO COLHEITADEIRA ======
let colheitadeira = {
  x: 100, // Posição X inicial
  y: 450, // Posição Y inicial
  largura: 150, // Largura visual da colheitadeira
  altura: 80, // Altura visual da colheitadeira
  velocidadeBase: 5, // Velocidade base da colheitadeira
  velocidadeBonus: 0, // Bônus de velocidade da melhoria
  visivel: false, // Começa invisível, ativada por comando do jogador
  anguloCortador: 0, // Ângulo para animar o cortador da colheitadeira
  nivelMelhoria: 0, // Nível atual de melhoria da colheitadeira (0 = sem melhoria)
  corDetalhe: [255, 200, 0] // Cor inicial do detalhe visual da colheitadeira (amarelo)
};

// ====== SISTEMA DE ECONOMIA E INVENTÁRIO ======
let itensColhidos = 0; // Contador de itens coletados na sessão atual de colheita
let saldo = 0; // Saldo de dinheiro do jogador
const PRECO_POR_ITEM_COLHIDO = 10; // Valor de venda por cada item colhido
const CUSTO_SEMENTE = 5; // Preço para comprar uma semente na loja

let sementesNoInventario = 5; // Quantidade inicial de sementes que o jogador possui

// ====== MELHORIAS DA COLHEITADEIRA ======
// Array de objetos definindo cada nível de melhoria da colheitadeira
const melhoriasColheitadeira = [
  {
    nivel: 1,
    custo: 50,
    velocidadeBonus: 2, // Aumenta a velocidade em 2
    corDetalhe: [0, 200, 255], // Azul claro
    descricao: "Velocidade +2 (Nível 1)"
  },
  {
    nivel: 2,
    custo: 150,
    velocidadeBonus: 3, // Aumenta a velocidade em mais 3 (total de +5 em relação à base)
    corDetalhe: [150, 0, 200], // Roxo
    descricao: "Velocidade +3 (Nível 2)"
  }
  // Você pode adicionar mais níveis aqui!
];


/**
 * Função `preload()`: Carrega ativos do jogo (imagens, sons, etc.) antes de `setup()`.
 * Atualmente, esta função é um placeholder para uma imagem de grama.
 */
function preload() {
  // Descomente a linha abaixo e ajuste o caminho se for usar uma imagem de grama
  // grama = loadImage('assets/grama.png');
}

/**
 * Função `setup()`: Configura o ambiente p5.js uma vez no início do programa.
 */
function setup() {
  createCanvas(800, 600); // Cria a tela de desenho com largura de 800px e altura de 600px
  background(100, 150, 50); // Define a cor de fundo inicial como um tom de verde para grama
  angleMode(RADIANS); // Garante que as funções de rotação (como `rotate()`) usem radianos

  // Inicializa a velocidade total da colheitadeira e a cor do detalhe
  colheitadeira.velocidade = colheitadeira.velocidadeBase + colheitadeira.velocidadeBonus;
  colheitadeira.corDetalhe = [255, 200, 0]; // Cor padrão amarela
}

/**
 * Função `draw()`: O loop principal do jogo, executado continuamente (60 vezes por segundo por padrão).
 * Responsável por redesenhar a tela e atualizar a lógica do jogo.
 */
function draw() {
  background(100, 150, 50); // Redesenha o fundo a cada frame para limpar a tela

  // Chama a função de desenho da tela correspondente ao estado atual do jogo
  if (estadoJogo === 'telaInicial') {
    desenhaTelaInicial();
  } else if (estadoJogo === 'jogando') {
    desenhaJogo();
  } else if (estadoJogo === 'telaVenda') {
    desenhaTelaVenda();
  } else if (estadoJogo === 'telaLoja') {
    desenhaTelaLoja();
  }
}

/**
 * Função `desenhaTelaInicial()`: Desenha a tela de título e o botão "JOGAR".
 */
function desenhaTelaInicial() {
  background(50, 100, 150); // Fundo azul escuro para a tela inicial

  fill(255, 255, 0); // Cor amarela para o texto do título
  textSize(60); // Tamanho da fonte
  textAlign(CENTER, CENTER); // Alinhamento centralizado
  text("PLANTE, COLHA E VENDA!", width / 2, height / 2 - 80); // Texto do título

  // Define as propriedades e desenha o botão "JOGAR"
  let botaoLargura = 200;
  let botaoAltura = 70;
  let botaoX = width / 2 - botaoLargura / 2;
  let botaoY = height / 2 + 50;

  fill(0, 150, 0); // Cor verde para o botão
  rect(botaoX, botaoY, botaoLargura, botaoAltura, 10); // Retângulo com cantos arredondados

  fill(255); // Cor branca para o texto do botão
  textSize(32);
  text("JOGAR", width / 2, botaoY + botaoAltura / 2 + 5); // Texto centralizado no botão
}

/**
 * Função `desenhaTelaVenda()`: Desenha a tela exibida após a colheita, mostrando o resultado e um botão para continuar.
 */
function desenhaTelaVenda() {
  background(150, 100, 50); // Fundo marrom para a tela de venda

  fill(255); // Cor branca para o texto
  textSize(40);
  textAlign(CENTER, CENTER);
  text("COLHEITA CONCLUÍDA!", width / 2, height / 2 - 100); // Título da tela de venda

  textSize(28);
  text("Você colheu: " + itensColhidos + " itens!", width / 2, height / 2 - 30); // Informa a quantidade colhida
  text("Você vendeu por: $" + (itensColhidos * PRECO_POR_ITEM_COLHIDO), width / 2, height / 2 + 10); // Informa o valor total da venda

  // Define as propriedades e desenha o botão "CONTINUAR"
  let botaoVendaLargura = 350;
  let botaoVendaAltura = 70;
  let botaoVendaX = width / 2 - botaoVendaLargura / 2;
  let botaoVendaY = height / 2 + 100;

  fill(200, 100, 0); // Cor laranja/marrom para o botão
  rect(botaoVendaX, botaoVendaY, botaoVendaLargura, botaoVendaAltura, 10); // Retângulo com cantos arredondados

  fill(255); // Cor branca para o texto do botão
  textSize(28);
  text("CONTINUAR", width / 2, botaoVendaY + botaoVendaAltura / 2 + 5); // Texto centralizado no botão
}

/**
 * Função `desenhaTelaLoja()`: Desenha a tela da loja, onde o jogador pode comprar sementes e melhorias.
 */
function desenhaTelaLoja() {
  background(100, 100, 150); // Fundo azul acinzentado para a loja

  fill(255); // Cor branca para o texto
  textSize(40);
  textAlign(CENTER, CENTER);
  text("LOJA DE SEMENTES E MELHORIAS", width / 2, height / 2 - 200); // Título da loja

  textSize(28);
  text("Seu Saldo: $" + saldo, width / 2, height / 2 - 130); // Exibe o saldo atual do jogador
  text("Sementes no Inventário: " + sementesNoInventario, width / 2, height / 2 - 90); // Exibe a quantidade de sementes no inventário
  text("Colheitadeira Nível: " + colheitadeira.nivelMelhoria + " (Velocidade: " + colheitadeira.velocidade + ")", width / 2, height / 2 - 50);

  // --- Botão Comprar Sementes ---
  let botaoComprarLargura = 250;
  let botaoComprarAltura = 70;
  let botaoComprarX = width / 2 - botaoComprarLargura / 2;
  let botaoComprarY = height / 2 + 20;

  fill(0, 150, 0); // Cor verde para o botão de compra de sementes
  rect(botaoComprarX, botaoComprarY, botaoComprarLargura, botaoComprarAltura, 10);

  fill(255);
  textSize(28);
  text("COMPRAR SEMENTE ($" + CUSTO_SEMENTE + ")", width / 2, botaoComprarY + botaoComprarAltura / 2 + 5);

  // --- Botões de Melhoria da Colheitadeira ---
  let offsetY = botaoComprarY + botaoComprarAltura + 30; // Começa abaixo do botão de sementes

  for (let i = 0; i < melhoriasColheitadeira.length; i++) {
    let melhoria = melhoriasColheitadeira[i];
    let melhoriaBotaoX = width / 2 - botaoComprarLargura / 2;
    let melhoriaBotaoY = offsetY + (i * (botaoAltura + 10)); // Posição de cada botão de melhoria

    fill(100, 50, 150); // Cor roxa para os botões de melhoria
    if (colheitadeira.nivelMelhoria >= melhoria.nivel) {
      fill(50, 50, 50); // Cinza se já comprada
    } else if (saldo < melhoria.custo) {
      fill(150, 150, 150); // Cinza mais claro se não tiver dinheiro
    }
    rect(melhoriaBotaoX, melhoriaBotaoY, botaoComprarLargura, botaoAltura, 10);

    fill(255);
    textSize(20);
    if (colheitadeira.nivelMelhoria >= melhoria.nivel) {
      text("ADQUIRIDO: " + melhoria.descricao, width / 2, melhoriaBotaoY + botaoAltura / 2 + 5);
    } else {
      text(melhoria.descricao + " ($" + melhoria.custo + ")", width / 2, melhoriaBotaoY + botaoAltura / 2 + 5);
    }
  }

  // --- Botão Voltar para o Jogo ---
  let botaoVoltarLargura = 200;
  let botaoVoltarAltura = 60;
  let botaoVoltarX = width / 2 - botaoVoltarLargura / 2;
  let botaoVoltarY = height - 70; // Posicionado mais acima para não sobrepor

  fill(150, 50, 0); // Cor marrom para o botão de voltar
  rect(botaoVoltarX, botaoVoltarY, botaoVoltarLargura, botaoVoltarAltura, 10);

  fill(255);
  textSize(24);
  text("VOLTAR AO JOGO", width / 2, botaoVoltarY + botaoVoltarAltura / 2 + 5);
}


/**
 * Função `desenhaJogo()`: Contém toda a lógica principal e o desenho da tela de jogo ativa.
 */
function desenhaJogo() {
  background(100, 150, 50); // Fundo verde de grama para a área de jogo

  // Desenha e atualiza o estado de cada semente/planta
  for (let i = 0; i < sementes.length; i++) {
    let sementeAtual = sementes[i];

    // Lógica de crescimento individual da planta com base no tempo
    if (sementeAtual.estagioCrescimento === 0 && millis() - sementeAtual.tempoPlantio >= TEMPO_CRESCIMENTO_ESTAGIO_1) {
      sementeAtual.estagioCrescimento = 1; // Avança para o estágio de broto
    } else if (sementeAtual.estagioCrescimento === 1 && millis() - sementeAtual.tempoPlantio >= TEMPO_CRESCIMENTO_ESTAGIO_2) {
      sementeAtual.estagioCrescimento = 2; // Avança para o estágio de planta média
    } else if (sementeAtual.estagioCrescimento === 2 && millis() - sementeAtual.tempoPlantio >= TEMPO_CRESCIMENTO_ESTAGIO_3) {
      sementeAtual.estagioCrescimento = 3; // Avança para o estágio de planta madura (pronta para colheita)
    }

    // Desenha a semente/planta de acordo com seu estágio de crescimento atual
    if (sementeAtual.estagioCrescimento === 0) {
      // Estágio 0: Semente recém-plantada (um pequeno círculo marrom)
      fill(sementeAtual.cor[0], sementeAtual.cor[1], sementeAtual.cor[2]);
      ellipse(sementeAtual.x, sementeAtual.y, sementeAtual.tamanho);
    } else if (sementeAtual.estagioCrescimento === 1) {
      // Estágio 1: Broto pequeno (retângulo verde vertical com base arredondada)
      fill(50, 180, 50);
      rect(sementeAtual.x - sementeAtual.tamanho / 4, sementeAtual.y - sementeAtual.tamanho, sementeAtual.tamanho / 2, sementeAtual.tamanho);
      ellipse(sementeAtual.x, sementeAtual.y, sementeAtual.tamanho / 2);
    } else if (sementeAtual.estagioCrescimento === 2) {
      // Estágio 2: Planta média (retângulo verde mais alto com corpo arredondado)
      fill(30, 150, 30);
      rect(sementeAtual.x - sementeAtual.tamanho / 4, sementeAtual.y - sementeAtual.tamanho * 1.5, sementeAtual.tamanho / 2, sementeAtual.tamanho * 1.5);
      ellipse(sementeAtual.x, sementeAtual.y - sementeAtual.tamanho * 1.5, sementeAtual.tamanho);
    } else if (sementeAtual.estagioCrescimento === 3) {
      // Estágio 3: Planta madura com fruto (retângulo verde alto com fruto amarelo no topo)
      fill(10, 120, 10);
      rect(sementeAtual.x - sementeAtual.tamanho / 4, sementeAtual.y - sementeAtual.tamanho * 2.5, sementeAtual.tamanho / 2, sementeAtual.tamanho * 2.5);
      ellipse(sementeAtual.x, sementeAtual.y - sementeAtual.tamanho * 2, sementeAtual.tamanho * 1.5);
      fill(255, 200, 0); // Cor amarela para o fruto
      ellipse(sementeAtual.x + sementeAtual.tamanho / 2, sementeAtual.y - sementeAtual.tamanho * 2.2, sementeAtual.tamanho / 2);
    }
  }

  // Lógica de desenho e movimento da colheitadeira
  if (colheitadeira.visivel) {
    push(); // Salva o estado atual das transformações para a colheitadeira
    translate(colheitadeira.x, colheitadeira.y); // Move o sistema de coordenadas para a posição da colheitadeira

    fill(180, 50, 50); // Corpo principal da colheitadeira (vermelho escuro)
    rect(0, 0, colheitadeira.largura, colheitadeira.altura);

    fill(colheitadeira.corDetalhe[0], colheitadeira.corDetalhe[1], colheitadeira.corDetalhe[2]); // Usa a cor de detalhe da melhoria
    rect(10, colheitadeira.altura - 20, colheitadeira.largura - 20, 20); // Desenha o detalhe

    push(); // Salva o estado para a rotação do cortador
    translate(colheitadeira.largura / 2, colheitadeira.altura - 10); // Move para o centro do cortador
    rotate(colheitadeira.anguloCortador); // Rotaciona o cortador
    fill(200, 150, 0); // Cor laranja para o cortador
    rect(-colheitadeira.largura / 4, -5, colheitadeira.largura / 2, 10); // Desenha o cortador
    pop(); // Restaura o estado de transformação do cortador

    fill(50); // Rodas (cinza escuro)
    ellipse(30, colheitadeira.altura + 10, 30); // Roda esquerda
    ellipse(colheitadeira.largura - 30, colheitadeira.altura + 10, 30); // Roda direita

    pop(); // Restaura o estado de transformação principal da colheitadeira

    colheitadeira.anguloCortador += 0.1; // Faz o cortador girar continuamente

    // Lógica de colisão e colheita de plantas pela colheitadeira
    for (let i = sementes.length - 1; i >= 0; i--) { // Loop reverso para evitar problemas ao remover itens
      let sementeAtual = sementes[i];

      // Define a área de colisão da colheitadeira
      let areaColheitaX_min = colheitadeira.x;
      let areaColheitaX_max = colheitadeira.x + colheitadeira.largura;
      let areaColheitaY_min = colheitadeira.y;
      let areaColheitaY_max = colheitadeira.y + colheitadeira.altura;

      // Verifica se a planta está pronta para colheita (estágio 3) e colide com a colheitadeira
      if (sementeAtual.estagioCrescimento === 3 &&
        sementeAtual.x > areaColheitaX_min &&
        sementeAtual.x < areaColheitaX_max &&
        sementeAtual.y > areaColheitaY_min &&
        sementeAtual.y < areaColheitaY_max) {

        criarParticulas(sementeAtual.x, sementeAtual.y, color(255, 200, 0)); // Cria partículas ao colher a planta

        sementes.splice(i, 1); // Remove a planta colhida do array de sementes
        itensColhidos++; // Incrementa o contador de itens colhidos
      }
    }
  }

  // Atualiza e desenha todas as partículas visíveis
  for (let i = particulas.length - 1; i >= 0; i--) {
    let p = particulas[i];
    p.update(); // Atualiza a posição e opacidade da partícula
    p.display(); // Desenha a partícula na tela
    if (p.isFinished()) {
      particulas.splice(i, 1); // Remove a partícula se ela já "desapareceu"
    }
  }

  // Desenho da interface de usuário (UI) do jogo
  fill(255); // Cor branca para o texto da UI
  textSize(24);
  textAlign(CENTER, CENTER);
  text("Minha Fazenda", width / 2, 30); // Título do jogo

  textSize(16);
  text("Sementes Plantadas: " + sementes.length + " / " + MAX_SEMENTES_PLANTADAS, width / 2, 60); // Exibe sementes plantadas
  text("Itens Colhidos: " + itensColhidos, width / 2, 85); // Exibe itens colhidos
  text("Saldo: $" + saldo, width / 2, 110); // Exibe o saldo atual do jogador
  text("Sementes no Inventário: " + sementesNoInventario, width / 2, 135); // Exibe sementes disponíveis para plantar
  text("Colheitadeira Nível: " + colheitadeira.nivelMelhoria + " (Velocidade: " + colheitadeira.velocidade + ")", width / 2, 160); // Exibe o nível da colheitadeira

  // Mensagens de instrução para o jogador com base no estado do jogo
  if (sementes.length < MAX_SEMENTES_PLANTADAS && sementesNoInventario > 0) {
    text("Clique para plantar!", width / 2, 195); // Instrução para plantar
  } else if (sementesNoInventario === 0 && sementes.length < MAX_SEMENTES_PLANTADAS) {
    text("Você não tem sementes! Vá para a loja (Pressione 'L')!", width / 2, 195); // Instrução para ir à loja
  } else if (sementes.length === MAX_SEMENTES_PLANTADAS) {
    text("Todas as áreas estão plantadas! Hora da colheita!", width / 2, 195); // Campo cheio
    text("Pressione 'C' para ligar/desligar a colheitadeira!", width / 2, 220); // Ativar colheitadeira
    text("Use W, A, S, D para mover a colheitadeira!", width / 2, 245); // Instrução de movimento
  } else {
    text("Aguarde suas plantas crescerem...", width / 2, 195); // Aguardando crescimento
  }

  // Lógica para transição para a tela de venda
  // Isso ocorre quando não há mais plantas prontas para colheita no campo e o jogador já colheu algo.
  let plantasProntasParaColheita = sementes.filter(s => s.estagioCrescimento === 3).length;
  if (sementes.length > 0 && plantasProntasParaColheita === 0 && itensColhidos > 0) {
    estadoJogo = 'telaVenda'; // Mudar para a tela de venda
  } else if (sementes.length === 0 && itensColhidos > 0) {
    // Caso todas as sementes (mesmo as que não cresceram) foram removidas da tela, mas algo foi colhido
    estadoJogo = 'telaVenda';
  }
}

/**
 * Função `mousePressed()`: Lida com os cliques do mouse em diferentes estados do jogo.
 */
function mousePressed() {
  // Lógica de clique na tela inicial
  if (estadoJogo === 'telaInicial') {
    let botaoLargura = 200;
    let botaoAltura = 70;
    let botaoX = width / 2 - botaoLargura / 2;
    let botaoY = height / 2 + 50;

    // Verifica se o clique foi no botão "JOGAR"
    if (mouseX > botaoX && mouseX < botaoX + botaoLargura &&
      mouseY > botaoY && mouseY < botaoY + botaoAltura) {
      estadoJogo = 'jogando'; // Altera para o estado de jogo
      reiniciarJogo(); // Reinicia o jogo para um novo ciclo
    }
  }
  // Lógica de clique na tela de venda
  else if (estadoJogo === 'telaVenda') {
    let botaoVendaLargura = 350;
    let botaoVendaAltura = 70;
    let botaoVendaX = width / 2 - botaoVendaLargura / 2;
    let botaoVendaY = height / 2 + 100;

    // Verifica se o clique foi no botão "CONTINUAR"
    if (mouseX > botaoVendaX && mouseX < botaoVendaX + botaoVendaLargura &&
      mouseY > botaoVendaY && mouseY < botaoVendaY + botaoVendaAltura) {
      saldo += itensColhidos * PRECO_POR_ITEM_COLHIDO; // Adiciona o valor da colheita ao saldo
      itensColhidos = 0; // Zera o contador de itens colhidos
      estadoJogo = 'jogando'; // Retorna para o estado de jogo
    }
  }
  // Lógica de clique na tela da loja
  else if (estadoJogo === 'telaLoja') {
    let botaoComprarLargura = 250;
    let botaoAltura = 70; // Reutiliza a altura do botão de sementes para melhorias

    let botaoComprarX = width / 2 - botaoComprarLargura / 2;
    let botaoComprarY = height / 2 + 20;

    // Verifica se o clique foi no botão "COMPRAR SEMENTE"
    if (mouseX > botaoComprarX && mouseX < botaoComprarX + botaoComprarLargura &&
      mouseY > botaoComprarY && mouseY < botaoComprarY + botaoAltura) {
      if (saldo >= CUSTO_SEMENTE) { // Verifica se há saldo suficiente para a compra
        saldo -= CUSTO_SEMENTE; // Debita o custo da semente do saldo
        sementesNoInventario++; // Adiciona uma semente ao inventário
        console.log("Semente comprada! Saldo: $" + saldo + ", Sementes: " + sementesNoInventario);
      } else {
        console.log("Saldo insuficiente para comprar semente!"); // Mensagem de erro
      }
    }

    // Lógica para cliques nos botões de melhoria da colheitadeira
    let offsetY = botaoComprarY + botaoAltura + 30; // Posição vertical para o primeiro botão de melhoria

    for (let i = 0; i < melhoriasColheitadeira.length; i++) {
      let melhoria = melhoriasColheitadeira[i];
      let melhoriaBotaoX = width / 2 - botaoComprarLargura / 2;
      let melhoriaBotaoY = offsetY + (i * (botaoAltura + 10));

      // Verifica se o clique foi neste botão de melhoria
      if (mouseX > melhoriaBotaoX && mouseX < melhoriaBotaoX + botaoComprarLargura &&
        mouseY > melhoriaBotaoY && mouseY < melhoriaBotaoY + botaoAltura) {

        // Só permite comprar se não foi comprado ainda e tem dinheiro
        if (colheitadeira.nivelMelhoria < melhoria.nivel && saldo >= melhoria.custo) {
          saldo -= melhoria.custo; // Deduza o custo
          colheitadeira.nivelMelhoria = melhoria.nivel; // Atualiza o nível da melhoria
          colheitadeira.velocidadeBonus += melhoria.velocidadeBonus; // Adiciona o bônus de velocidade
          colheitadeira.velocidade = colheitadeira.velocidadeBase + colheitadeira.velocidadeBonus; // Atualiza velocidade total
          colheitadeira.corDetalhe = melhoria.corDetalhe; // Atualiza a cor do detalhe visual
          console.log("Melhoria de colheitadeira comprada! Nível: " + colheitadeira.nivelMelhoria + ", Saldo: $" + saldo);
        } else if (colheitadeira.nivelMelhoria >= melhoria.nivel) {
          console.log("Esta melhoria já foi comprada!");
        } else {
          console.log("Saldo insuficiente para esta melhoria!");
        }
      }
    }


    let botaoVoltarLargura = 200;
    let botaoVoltarAltura = 60;
    let botaoVoltarX = width / 2 - botaoVoltarLargura / 2;
    let botaoVoltarY = height - 70;

    // Verifica se o clique foi no botão "VOLTAR AO JOGO"
    if (mouseX > botaoVoltarX && mouseX < botaoVoltarX + botaoVoltarLargura &&
      mouseY > botaoVoltarY && mouseY < botaoVoltarY + botaoVoltarAltura) {
      estadoJogo = 'jogando'; // Retorna para o estado de jogo
    }

  }
  // Lógica de plantio de sementes (apenas no estado 'jogando')
  else if (estadoJogo === 'jogando') {
    // Permite plantar sementes apenas se houver espaço no campo e sementes no inventário
    if (sementes.length < MAX_SEMENTES_PLANTADAS && sementesNoInventario > 0) {
      let novaSemente = {
        x: mouseX, // Coordenada X do clique do mouse
        y: mouseY, // Coordenada Y do clique do mouse
        tamanho: 10, // Tamanho inicial da semente
        cor: [100, 70, 20], // Cor marrom da semente
        estagioCrescimento: 0, // Estágio inicial
        tempoPlantio: millis() // Registra o tempo de plantio para o crescimento individual
      };
      sementes.push(novaSemente); // Adiciona a nova semente ao array
      sementesNoInventario--; // Consome uma semente do inventário
    } else if (sementesNoInventario === 0) {
      console.log("Você não tem sementes para plantar!");
    } else if (sementes.length >= MAX_SEMENTES_PLANTADAS) {
      console.log("Você já plantou o máximo de sementes!");
    }
  }
}

/**
 * Função `keyPressed()`: Lida com eventos de teclado.
 */
function keyPressed() {
  // Lógica de teclado no estado 'jogando'
  if (estadoJogo === 'jogando') {
    // Ativa/desativa a colheitadeira com a tecla 'C'
    if (key === 'c' || key === 'C') {
      colheitadeira.visivel = !colheitadeira.visivel; // Alterna a visibilidade da colheitadeira
      if (colheitadeira.visivel) {
        // Posiciona a colheitadeira no centro inferior da tela quando ativada
        colheitadeira.x = width / 2 - colheitadeira.largura / 2;
        colheitadeira.y = height - colheitadeira.altura - 20;
      }
    }
    // Muda para a tela da loja com a tecla 'L'
    else if (key === 'l' || key === 'L') {
      estadoJogo = 'telaLoja';
    }

    // Lógica de movimento da colheitadeira (somente se estiver visível)
    if (colheitadeira.visivel) {
      if (key === 'a' || key === 'A') { // Move para a esquerda
        colheitadeira.x -= colheitadeira.velocidade;
      } else if (key === 'd' || key === 'D') { // Move para a direita
        colheitadeira.x += colheitadeira.velocidade;
      } else if (key === 'w' || key === 'W') { // Move para cima
        colheitadeira.y -= colheitadeira.velocidade;
      } else if (key === 's' || key === 'S') { // Move para baixo
        colheitadeira.y += colheitadeira.velocidade;
      }
      // Restringe o movimento da colheitadeira dentro dos limites da tela
      colheitadeira.x = constrain(colheitadeira.x, 0, width - colheitadeira.largura);
      colheitadeira.y = constrain(colheitadeira.y, 0, height - colheitadeira.altura);
    }
  }
  // Lógica de teclado na tela da loja
  else if (estadoJogo === 'telaLoja') {
    // Permite sair da loja com a tecla 'Escape'
    if (key === 'escape' || key === 'Escape') {
      estadoJogo = 'jogando'; // Retorna para o estado de jogo
    }
  }
}

/**
 * Função `reiniciarJogo()`: Reseta as variáveis relacionadas ao campo de jogo para um novo ciclo.
 * O saldo, o inventário de sementes e as melhorias da colheitadeira são mantidos.
 */
function reiniciarJogo() {
  sementes = []; // Limpa todas as sementes plantadas no campo
  itensColhidos = 0; // Zera o contador de itens colhidos
  colheitadeira.visivel = false; // Desativa a colheitadeira
  colheitadeira.anguloCortador = 0; // Reseta o ângulo do cortador
  particulas = []; // Limpa todas as partículas visíveis
  // O saldo, sementesNoInventario e melhorias da colheitadeira são mantidos
}

/**
 * Função `criarParticulas()`: Gera um conjunto de partículas em uma posição e cor específicas.
 * Usada para criar o efeito visual de "colheita" quando uma planta é coletada.
 * @param {number} x - Coordenada X onde as partículas serão criadas.
 * @param {number} y - Coordenada Y onde as partículas serão criadas.
 * @param {p5.Color} corParticula - A cor das partículas.
 */
function criarParticulas(x, y, corParticula) {
  let numParticulas = random(5, 15); // Gera um número aleatório de partículas
  for (let i = 0; i < numParticulas; i++) {
    particulas.push(new Particle(x, y, corParticula)); // Adiciona uma nova partícula ao array
  }
}

/**
 * Classe `Particle`: Representa uma única partícula para efeitos visuais.
 */
class Particle {
  /**
   * Construtor da partícula.
   * @param {number} x - Posição X inicial da partícula.
   * @param {number} y - Posição Y inicial da partícula.
   * @param {p5.Color} cor - Cor da partícula.
   */
  constructor(x, y, cor) {
    this.x = x;
    this.y = y;
    this.vx = random(-2, 2); // Velocidade aleatória no eixo X
    this.vy = random(-5, -1); // Velocidade aleatória no eixo Y (para cima)
    this.alpha = 255; // Opacidade inicial (totalmente visível)
    this.tamanho = random(3, 8); // Tamanho aleatório da partícula
    this.cor = cor; // Cor da partícula
  }

  /**
   * Atualiza o estado da partícula (posição e opacidade) a cada frame.
   */
  update() {
    this.x += this.vx; // Atualiza a posição X
    this.y += this.vy; // Atualiza a posição Y
    this.alpha -= 5; // Diminui a opacidade para a partícula desaparecer gradualmente
  }

  /**
   * Desenha a partícula na tela.
   */
  display() {
    noStroke(); // Remove qualquer borda do círculo
    // Define a cor da partícula com a opacidade atual
    fill(red(this.cor), green(this.cor), blue(this.cor), this.alpha);
    ellipse(this.x, this.y, this.tamanho); // Desenha a partícula como um círculo
  }

  /**
   * Verifica se a partícula já terminou sua animação e pode ser removida.
   * @returns {boolean} - Retorna `true` se a opacidade for menor que 0, indicando que a partícula desapareceu.
   */
  isFinished() {
    return this.alpha < 0;
  }
}
